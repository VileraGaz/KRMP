package com.example.kursproject.tables

data class Operation(
    val type: Boolean, // Тип операции (расход или доход)
    val amount: Double, // Сумма операции
    val date: Long, // Дата операции (в формате "гггг-мм-дд")
    val category_expense: String, // Категория операции расходов
    val category_income: String, // Категория операции доходов
    val subcategory: String, // подкатегория
    val iconResourceId: Int

)


package com.example.kursproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.example.kursproject.databinding.ActivityChoiseBinding
import com.example.kursproject.tables.User
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase

class Choise : AppCompatActivity() {
    lateinit var launcher: ActivityResultLauncher<Intent>
    lateinit var auth: FirebaseAuth
    lateinit var binding: ActivityChoiseBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChoiseBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth
        launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            val task = GoogleSignIn.getSignedInAccountFromIntent(it.data)
            try {
                val account = task.getResult(ApiException::class.java)
                if (account!=null){
                    firebaseAuthWithGoogle(account.idToken!!) // если норм, то подключаем аккаунт
                }
            }
            catch (e: ApiException) {
                Log.d("MyLog", "launcher false")
            }
        }
        checkAuthState() // если мы уже зарегистрированы, то сразу откроется MainActivity
    }

    // висит на кнопке регистрация
    fun clickerRegister(view: View) {
        startActivity(Intent(this@Choise, RegisterActivity::class.java))
    }
    // висит на кнопке входа
    fun loginRegister(view: View) {
        startActivity(Intent(this@Choise, LoginActivity::class.java))
    }

    private fun getClient(): GoogleSignInClient {
        val gso = GoogleSignInOptions
            .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        return GoogleSignIn.getClient(this, gso)
    }

    // висит на кнопке входа через гугл
    fun clickerGoogle(view: View) {
        val signInClient = getClient()
        launcher.launch(signInClient.signInIntent)
    }

    private fun firebaseAuthWithGoogle(idToken: String){
        val cridencial = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(cridencial).addOnCompleteListener{
            if(it.isSuccessful){
//                val mainIntent = Intent(this@Choise, MainActivity::class.java)
//                startActivity(mainIntent)
                Log.d("MyLog", "GoogleSignIn task")
                checkAuthState()
            }
            else{
                Log.d("MyLog", "GoogleSignIn false")
            }
        }
    }

    private fun checkAuthState() {
        if (auth.currentUser != null) { // Пользователь вошел в аккаунт
            val userId = auth.currentUser?.uid ?: ""
            val databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userId)
            databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Данные пользователя уже существуют, это не первый вход
                        val i = Intent(this@Choise, MainActivity::class.java)
                        startActivity(i)
                    } else {
                        // Данные пользователя отсутствуют, это первый вход
                        // Вы можете выполнить необходимые действия для первого входа

                        val email = auth.currentUser?.email ?: "" // Получение электронной почты пользователя
                        val username = if (email.isNotEmpty()) {
                            email.substringBefore('@') // Извлечение имени пользователя из адреса электронной почты
                        } else {
                            "" // Если электронная почта недоступна, устанавливаем пустое значение для имени пользователя
                        }
                        val user = User(
                            id = FirebaseAuth.getInstance().currentUser?.uid ?: "",
                            email = email,
                            username = username,
                            userOperations = mutableListOf()
                        )
                        FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().currentUser!!.uid)
                            .setValue(user)
                        // Здесь я просто выведу лог сообщение
                        Log.d("MyLog", "Первый вход пользователя")
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Обработка ошибки при чтении данных из базы данных
                    Log.e("MyLog", "Ошибка при проверке состояния аутентификации: ${error.message}")
                }
            })
        }
    }
















}
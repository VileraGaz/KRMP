package com.example.kursproject.fragments

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.ViewModel
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kursproject.OperationCategoryActivity
import com.example.kursproject.R
import com.example.kursproject.tables.Operation
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryFragment : Fragment() {


    private lateinit var recyclerView: RecyclerView
    private lateinit var operationsAdapter: OperationsAdapter
    private lateinit var operationsList: MutableList<Operation>
    private lateinit var periodButton: Button
    private lateinit var typeButton: Button
    private lateinit var button2: Button
    private lateinit var categoryResultLauncher: ActivityResultLauncher<Intent>
    private var selectedCategory: String? = null
    private var type: Boolean = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_history, container, false)
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)
        operationsList = mutableListOf()
        operationsAdapter = OperationsAdapter(operationsList)
        recyclerView.adapter = operationsAdapter

        categoryResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                selectedCategory = result.data?.getStringExtra("thisCategoryName")
                filterOperationsByCategory(selectedCategory)
            }
        }

        val userId = FirebaseAuth.getInstance().currentUser?.uid
        val databaseReference = FirebaseDatabase.getInstance().getReference("Users/$userId/Operations")
        operationsList.sortByDescending { it.date }

        periodButton = view.findViewById(R.id.button)
        typeButton = view.findViewById(R.id.button3)
        typeButton.setOnClickListener {
            showTypeOptionsDialog()
        }

        button2 = view.findViewById(R.id.button2)

        button2.setOnClickListener {
            if (typeButton.text == "Тип операции") {
                Toast.makeText(requireContext(), "Сначала выберите тип операции", Toast.LENGTH_SHORT).show()
            } else {
            val intent = Intent(requireContext(), OperationCategoryActivity::class.java)
            intent.putExtra("type", if (type) "expenseCategories" else "incomeCategories")
            categoryResultLauncher.launch(intent)
            selectedCategory?.let { category ->
                val filteredList = operationsList.filter { operation ->
                    if (type) {
                        operation.category_expense == category
                    } else {
                        operation.category_income == category
                    }
                }

                operationsAdapter.updateList(filteredList)
            }
            }}

        periodButton.setOnClickListener {
            showDatePicker()
        }

        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (operationSnapshot in dataSnapshot.children) {
                    val amount = operationSnapshot.child("amount").getValue(Double::class.java) ?: 0.0
                    val categoryExpense = operationSnapshot.child("category_expense").getValue(String::class.java) ?: ""
                    val categoryIncome = operationSnapshot.child("category_income").getValue(String::class.java) ?: ""
                    val date = operationSnapshot.child("date").getValue(Long::class.java) ?: 0L
                    val type = operationSnapshot.child("type").getValue(Boolean::class.java) ?: false
                    val iconResourceId = operationSnapshot.child("iconResourceId").getValue(Int::class.java) ?: R.drawable.food

                    val operation = Operation(type, amount, date, categoryExpense, categoryIncome, "null", iconResourceId)
                    operationsList.add(operation)
                }
                operationsList.sortByDescending { it.date }

                operationsAdapter.notifyDataSetChanged()
                operationsAdapter.updateList(operationsList)
                val navController = findNavController()
                if (operationsList.isEmpty()) {
                    // Если список пуст, отобразить фрагмент "Нет записей"
                    navController.navigate(R.id.action_historyFragment_to_fragmentNothingHistory)
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle errors
            }
        })

        return view
    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    private fun filterOperationsByCategory(category: String?) {
        val filteredList = if (type) {
            operationsList.filter { it.category_expense == category }
        } else {
            operationsList.filter { it.category_income == category }
        }
        operationsAdapter.updateList(filteredList)

        category?.let {
            button2.text = it
            button2.setTextColor(Color.parseColor("#2080EE")) // Изменение цвета текста на синий
        }
    }

    private fun showDatePicker() {
        val datePicker = MaterialDatePicker.Builder.dateRangePicker()
            .setTitleText("Выберите период")
            .setPositiveButtonText("Сохранить")
            .build()
        Locale.setDefault(Locale("ru"))
        datePicker.show(parentFragmentManager, "Datepicker")
        datePicker.addOnPositiveButtonClickListener { selection ->
            val startDate = selection.first
            val endDate = selection.second

            filterOperationsByDateRange(startDate, endDate)

            val formattedStartDate = formatDate(startDate)
            val formattedEndDate = formatDate(endDate)

            periodButton.text = "$formattedStartDate - $formattedEndDate" // Update button text
            periodButton.setTextColor((Color.parseColor("#2080EE"))) // Change text color to blue
        }

    }

    private fun formatDate(date: Long): String {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale("ru"))
        return sdf.format(Date(date))
    }


    private fun Double.formatAmountWithCurrency(currencySymbol: String): String {
        val formattedAmount = if (this == this.toLong().toDouble()) {
            String.format("%.0f", this)
        } else {
            String.format("%.2f", this)
        }
        return "$formattedAmount $currencySymbol"
    }



    private fun filterOperationsByDateRange(startDate: Long, endDate: Long) {
        val filteredList = operationsList.filter { operation ->
            operation.date in startDate..endDate
        }
        operationsAdapter.updateList(filteredList)
    }


    private fun showTypeOptionsDialog() {
        val items = arrayOf("Расход", "Доход")
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Выберите тип")
        builder.setItems(items) { dialog, which ->
            val selectedType = items[which]
            typeButton.text = selectedType // Update button text with selected type
            type = selectedType == "Расход"
            typeButton.setTextColor(Color.parseColor("#2080EE")) // Change text color to blue

            filterOperationsByType(selectedType)
        }
        val dialog = builder.create()
        dialog.show()
    }

    private fun filterOperationsByType(selectedType: String) {
        val filteredList = if (selectedType == "Расход") {
            operationsList.filter { it.type && it.category_expense.isNotEmpty() }
        } else {
            operationsList.filter { !it.type && it.category_income.isNotEmpty() }
        }
        operationsAdapter.updateList(filteredList)
    }




    private inner class OperationsAdapter(private var operations: List<Operation>) : RecyclerView.Adapter<OperationViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OperationViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_operation, parent, false)
            return OperationViewHolder(view)
        }

        override fun onBindViewHolder(holder: OperationViewHolder, position: Int) {
            val operation = operations[position]
            holder.bind(operation, position)
        }

        override fun getItemCount(): Int {
            return operations.size
        }

        fun updateList(newList: List<Operation>) {
            operations = newList
            notifyDataSetChanged()
        }
    }

    private inner class OperationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val dateTextView: TextView = itemView.findViewById(R.id.dateTextView)
        private val amountTextView: TextView = itemView.findViewById(R.id.amountTextView)
        private val categoryTextView: TextView = itemView.findViewById(R.id.categoryExpenseTextView)
        private val icon: ImageView = itemView.findViewById(R.id.imageView3)

        fun bind(operation: Operation, position: Int) {
            val sdf = SimpleDateFormat("dd MMMM yyyy", Locale("ru")) // Устанавливаем формат даты
            val date = Date(operation.date) // Преобразуем миллисекунды в объект типа Date
            val formattedDate = sdf.format(date) // Форматируем дату в соответствии с выбранным форматом

            dateTextView.text = formattedDate // Устанавливаем отформатированную дату
            amountTextView.text = if (operation.type) "-${operation.amount.formatAmountWithCurrency("₽")}" else operation.amount.formatAmountWithCurrency("₽")
            categoryTextView.text = if (operation.type) operation.category_expense else operation.category_income
            icon.setImageResource(operation.iconResourceId)

//            if (operation.category_expense == "Здоровье") {
//                icon.setImageResource(R.drawable.health)
//            } else if (operation.category_expense == "Продукты") {
//                icon.setImageResource(R.drawable.food)
//            } else if (operation.category_expense == "Транспорт") {
//                icon.setImageResource(R.drawable.bus)
//            }
//            else if (operation.category_expense == "Одежда") {
//                icon.setImageResource(R.drawable.shirt)
//            }
//            else if (operation.category_expense == "Дом") {
//                icon.setImageResource(R.drawable.home)
//            }
//            else if (operation.category_expense == "Спорт") {
//                icon.setImageResource(R.drawable.sport)
//            }
//            else if (operation.category_expense == "Развлечения") {
//                icon.setImageResource(R.drawable.funny)
//            }
//
//            if (operation.category_income == "Инвестиции") {
//                icon.setImageResource(R.drawable.invest)
//            } else if (operation.category_income == "Зарплата") {
//                icon.setImageResource(R.drawable.salary)
//            } else if (operation.category_income == "Подарки") {
//                icon.setImageResource(R.drawable.gift)
//            }
        }
    }

}

class HistoryViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
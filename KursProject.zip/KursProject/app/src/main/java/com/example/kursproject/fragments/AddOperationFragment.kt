package com.example.kursproject.fragments

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.ViewModel
import com.example.kursproject.OperationCategoryActivity
import com.example.kursproject.R
import com.example.kursproject.databinding.FragmentAddOperationBinding
import com.example.kursproject.tables.Operation
import com.example.kursproject.tables.User
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AddOperationFragment : Fragment() {

    private lateinit var viewModel: AddOperationViewModel
    lateinit var binding: FragmentAddOperationBinding
    lateinit var auth: FirebaseAuth
    private lateinit var categoryResultLauncher: ActivityResultLauncher<Intent>
    private var selectedDate: Date = Date()
    private var isTodaySelected: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        categoryResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val selectedCategory = result.data?.getStringExtra("thisCategoryName")
                val selectedSubcategory = result.data?.getStringExtra("thisSubcategoryName") ?: ""
                val selectedImageId = result.data?.getIntExtra("thisImageId", R.drawable.food) ?: R.drawable.food
                binding.chooseCatName.text = selectedCategory.toString()
                binding.chooseImage.setImageResource(selectedImageId)
                binding.chooseImage.setTag(selectedImageId)
                binding.chooseSubcatName.text = selectedSubcategory

            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentAddOperationBinding.inflate(inflater, container, false)

        auth = Firebase.auth

        // Первоначально установим категории расходов
        funOfShow("expenseCategories")
        var type = true // true - расход

        binding.add.setOnClickListener {
            if (validateFields()) {
                addOperation(type)
            }

        }

        binding.consumption.setOnClickListener {
            type = true
            binding.consumption.setBackgroundColor(Color.parseColor("#2080EE"))
            binding.income.setBackgroundColor(Color.parseColor("#F7F7F9"))
            binding.consumption.setTextColor(Color.parseColor("#F7F7F9"))
            binding.income.setTextColor(Color.parseColor("#2080EE"))
            funOfShow("expenseCategories")
        }

        binding.income.setOnClickListener {
            type = false
            binding.income.setBackgroundColor(Color.parseColor("#2080EE"))
            binding.consumption.setBackgroundColor(Color.parseColor("#F7F7F9"))
            binding.income.setTextColor(Color.parseColor("#F7F7F9"))
            binding.consumption.setTextColor(Color.parseColor("#2080EE"))
            funOfShow("incomeCategories")
        }

        binding.chooseCat.setOnClickListener {
            val intent = Intent(requireContext(), OperationCategoryActivity::class.java)
            intent.putExtra("type", if (type) "expenseCategories" else "incomeCategories")
            categoryResultLauncher.launch(intent)
        }

        binding.today.setOnClickListener {
            isTodaySelected = true
            updateSelectedDate()
        }

        binding.yesterday.setOnClickListener {
            isTodaySelected = false
            updateSelectedDate()
        }

        binding.chooseDate.setOnClickListener {
            showDatePicker()
            binding.chooseDate.setTextColor(Color.parseColor("#2080EE"))
            binding.today.setTextColor((Color.parseColor("#838383")))
            binding.yesterday.setTextColor((Color.parseColor("#838383")))
        }

        // Установим начальную дату
        updateSelectedDate()


        return binding.root
    }

    private fun funOfShow(type : String){
        val currentUser = getCurrentUser()

        currentUser?.id?.let { userId ->
            val databaseReference = FirebaseDatabase.getInstance().getReference().child("Users")
                .child(userId).child("userCategories").child(type)
            changeTypeOfCategory(databaseReference)
        }
    }

    private fun updateSelectedDate() {
        if (isTodaySelected) {
            selectedDate = Date() // Получаем сегодняшнюю дату
            binding.today.setTextColor((Color.parseColor("#2080EE")))
            binding.yesterday.setTextColor((Color.parseColor("#838383")))
        } else {
            selectedDate = getYesterday()
            binding.today.setTextColor((Color.parseColor("#838383")))
            binding.yesterday.setTextColor((Color.parseColor("#2080EE")))
        }
    }

    private fun getYesterday(): Date {
        val calendar = Calendar.getInstance()
        calendar.time = Date()
        calendar.add(Calendar.DAY_OF_YEAR, -1) // Уменьшаем текущую дату на 1 день
        return calendar.time
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(requireContext(),
            { view, year, monthOfYear, dayOfMonth ->
                val selectedCalendar = Calendar.getInstance()
                selectedCalendar.set(year, monthOfYear, dayOfMonth)
                selectedDate = selectedCalendar.time

                val formattedDate = SimpleDateFormat("d MMMM", Locale("ru")).format(selectedDate)
                binding.chooseDate.text = formattedDate
            }, year, month, day)

        datePickerDialog.show()
    }



    private fun changeTypeOfCategory(categoriesReference: DatabaseReference) {
        categoriesReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val categoryNames = mutableListOf<String>()
                for (categorySnapshot in dataSnapshot.children) {
                    val categoryName = categorySnapshot.child("name").getValue(String::class.java)
                    categoryName?.let {
                        categoryNames.add(it)
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                showToast("Ошибка при загрузке категорий: ${databaseError.message}")
            }
        })
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(AddOperationViewModel::class.java)
        // TODO: Use the ViewModel


    }

    private fun validateFields(): Boolean {
        val amountText = binding.sum.text.toString()
        val categorySelected = binding.chooseCatName.text.toString()

        return when {
            amountText.isEmpty() -> {
                showToast("Введите сумму")
                false
            }
            categorySelected == "Категория" -> {
                showToast("Выберите категорию")
                false
            }
            else -> true
        }
    }

    private fun addOperation(type: Boolean) {

        val database = Firebase.database
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        val userOperationsRef = database.getReference("Users/$userId/Operations")
        val amountText = binding.sum.text.toString()
        val amount = amountText.replace(',', '.').toDoubleOrNull() ?: 0.0
        val date = selectedDate.time
        Log.d("proverk", "$selectedDate")
        val category = binding.chooseCatName.text.toString()
        val subcategory = binding.chooseSubcatName.text.toString()
        val iconResourceId = binding.chooseImage.getTag() as? Int  ?: R.drawable.food

        val currentUser = getCurrentUser()

        val operation = Operation(
            type = type,
            amount = amount,
            date = date,
            category_expense = if (type == true) category else "", // Поле категории расходов
            category_income = if (type == false) category else "", // Поле категории доходов
            subcategory = subcategory,
            iconResourceId = iconResourceId
        )

        currentUser?.addOperation(operation)

        // Обновляем данные в базе данных или хранилище
        val newOperationRef = userOperationsRef.push()
        newOperationRef.setValue(operation)

        showToast("Операция добавлена")

        binding.sum.text.clear()
    }



    private fun getCurrentUser(): User? {
        val firebaseUser = auth.currentUser // Получаем текущего пользователя Firebase
        return if (firebaseUser != null) {
            // Пользователь аутентифицирован, возвращаем объект User с категориями по умолчанию
            User(id = firebaseUser.uid,
                username = "",
                email = "",
                userOperations = mutableListOf()) // Передаем пустые значения для username и email
        } else {
            // Пользователь не аутентифицирован, возвращаем null или выполняем необходимые действия
            null
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }


}

class AddOperationViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}


package com.example.kursproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.widget.Toast
import com.example.kursproject.databinding.ActivityLoginBinding
import com.example.kursproject.databinding.ActivityRegisterBinding
import com.example.kursproject.tables.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class RegisterActivity : AppCompatActivity() {

    lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.passwordEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        binding.signUpBtn.setOnClickListener{
            if (binding.emailEt.text.isEmpty() || binding.passwordEt.text.isEmpty() || binding.usernameEt.text.isEmpty()) {
                Toast.makeText(applicationContext, "Поля не могут быть пустыми", Toast.LENGTH_SHORT).show()
            }
            else{
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(binding.emailEt.text.toString(), binding.passwordEt.text.toString())
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val user = User(
                                id = FirebaseAuth.getInstance().currentUser?.uid ?: "",
                                username = binding.usernameEt.text.toString(),
                                email = binding.emailEt.text.toString(),
                                userOperations = mutableListOf()
                            )
                            FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().currentUser!!.uid)
                                .setValue(user)

                            startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                        }
                    }

            }
        }
    }
}
package com.example.kursproject

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate

// Create a Theme Manager class to manage the app's theme

//class ThemeManager(private val context: Context) {
//    private val themePreferenceName = "theme_pref"
//    private val themePreferenceKey = "theme_key"
//    private val themePreferences: SharedPreferences = context.getSharedPreferences(themePreferenceName, Context.MODE_PRIVATE)
//
//    fun applyTheme() {
//        val isNightMode = themePreferences.getBoolean(themePreferenceKey, false)
//        if (isNightMode) {
//            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//        } else {
//            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
//        }
//    }
//
//    fun setTheme(isNightMode: Boolean) {
//        themePreferences.edit().putBoolean(themePreferenceKey, isNightMode).apply()
//        applyTheme()
//    }
//}

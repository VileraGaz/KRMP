package com.example.kursproject.tables

import android.widget.ImageView

data class Category(
    val name: String,
    val iconResourceId: Int,
    val subcategories: MutableList<String> = mutableListOf() // Список подкатегорий
) {
    // Дополнительный конструктор для удобства создания категорий с подкатегориями по умолчанию
    constructor(name: String, iconResourceId: Int, vararg subcategories: String) : this(name, iconResourceId, subcategories.toMutableList())
}
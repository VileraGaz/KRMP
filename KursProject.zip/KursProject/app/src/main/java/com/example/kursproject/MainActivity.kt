package com.example.kursproject


import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import androidx.preference.PreferenceManager
import com.example.kursproject.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installSplashScreen()
        binding = ActivityMainBinding.inflate(layoutInflater)
        applyTheme()
        setContentView(binding.root)
        auth = Firebase.auth

        if (FirebaseAuth.getInstance().currentUser == null) {
            startActivity(Intent(this@MainActivity, Choise::class.java))
        }

        // Navigation для переключения снизу
        val navView: BottomNavigationView = findViewById(R.id.bNav)
        val navController = findNavController(R.id.fragment)
        navView.setupWithNavController(navController)
        binding.fabAdd.setOnClickListener { view -> navController.navigate(R.id.addOperationFragment) }
    }

    private fun applyTheme() {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        val useSystemTheme = sharedPreferences.getBoolean("use_system_theme", true)
        val theme = if (useSystemTheme) {
            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        } else {
            when (sharedPreferences.getString("app_theme", "system")) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        }
        AppCompatDelegate.setDefaultNightMode(theme)
    }

}


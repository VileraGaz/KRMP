package com.example.kursproject.tables

import com.example.kursproject.R

data class UserCategories(
    val expenseCategories: MutableList<Category> = mutableListOf(
        Category("Продукты", R.drawable.food, "Мясо", "Овощи", "Фрукты"),
        Category("Транспорт", R.drawable.bus, "Автомобиль", "Общественный транспорт"),
        Category("Развлечения", R.drawable.funny, "Кино", "Театр", "Концерты"),
        Category("Одежда", R.drawable.shirt),
        Category("Дом", R.drawable.home),
        Category("Спорт", R.drawable.sport),
        Category("Здоровье", R.drawable.health)
    ),
    val incomeCategories: MutableList<Category> = mutableListOf(
        Category("Зарплата",  R.drawable.salary),
        Category("Инвестиции",  R.drawable.invest),
        Category("Подарки",  R.drawable.gift, "День рождения", "Новый год")
    )
)

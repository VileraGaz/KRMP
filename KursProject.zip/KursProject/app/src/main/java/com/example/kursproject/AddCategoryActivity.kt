package com.example.kursproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kursproject.databinding.ActivityAddCategoryBinding
import com.example.kursproject.databinding.ItemCategoryBinding
import com.example.kursproject.databinding.ItemSubcategoryBinding
import com.example.kursproject.tables.User
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class AddCategoryActivity : AppCompatActivity() {

    lateinit var auth: FirebaseAuth
    lateinit var binding: ActivityAddCategoryBinding
    private lateinit var subcategoryAdapter: SubcategoryAdapter
    private val subcategoriesList = mutableListOf<String>()
    private val iconList = listOf(
        R.drawable.bus, R.drawable.food, R.drawable.funny,
        R.drawable.gift, R.drawable.health, R.drawable.home, R.drawable.invest,
        R.drawable.shirt, R.drawable.sport, R.drawable.salary
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddCategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        val type = intent.getStringExtra("type") ?: ""
        binding.selectImage.setImageResource(R.drawable.food) // дефолт изображение
        binding.selectImage.setTag(R.drawable.food)

        binding.tvSubcategories.visibility = View.GONE
        binding.rvSubcategories.visibility = View.GONE

        binding.btnAddCategory.setOnClickListener{
            addCategory(type)
        }

        binding.btnAddSubcategory.setOnClickListener{
            addSubcategory()
            binding.tvSubcategories.visibility = View.VISIBLE
            binding.rvSubcategories.visibility = View.VISIBLE
        }

        subcategoryAdapter = SubcategoryAdapter(subcategoriesList)
        binding.rvSubcategories.adapter = subcategoryAdapter
        binding.rvSubcategories.layoutManager = LinearLayoutManager(this)

        subcategoryAdapter.setOnDeleteClickListener { position ->
            subcategoriesList.removeAt(position)
            subcategoryAdapter.notifyItemRemoved(position)
        }

        binding.selectImage.setOnClickListener {
            val popupView = layoutInflater.inflate(R.layout.popup_bubble, null)

            // Инициализация RecyclerView внутри PopupWindow
            val popupRecyclerView = popupView.findViewById<RecyclerView>(R.id.recyclerViewIcons)
            val layoutManager = GridLayoutManager(this@AddCategoryActivity, 3)
            popupRecyclerView.layoutManager = layoutManager
            val iconAdapter = IconAdapter(iconList)
            popupRecyclerView.adapter = iconAdapter

            // Создание PopupWindow
            val focusable = true // Позволяет PopupWindow закрываться при нажатии вне его области
            val width = resources.displayMetrics.widthPixels * 0.8 // Настройка ширины PopupWindow на 80% ширины экрана
            val height = ViewGroup.LayoutParams.WRAP_CONTENT
            val popupWindow = PopupWindow(popupView, width.toInt(), height, focusable)

            // Показ PopupWindow в окне с фокусом
            popupWindow.showAtLocation(binding.root, Gravity.CENTER_HORIZONTAL, 0, -100)

            // Обработка выбора иконки
            iconAdapter.setOnItemClickListener { selectedIcon ->
                // Установка выбранной иконки в selectImage
                binding.selectImage.setImageResource(selectedIcon)
                binding.selectImage.setTag(selectedIcon)
                // Закрытие PopupWindow
                popupWindow.dismiss()
            }
        }

        binding.OKbtn.setOnClickListener{
            finish()
        }
    }

    private fun addCategory(type: String) {
        val currentUser = getCurrentUser()
        if (currentUser != null) {
            val categoryName = binding.etAddCategory.text.toString().trim()
            val imageId = binding.selectImage.getTag() as? Int
            if (categoryName.isNotEmpty()) {
                val databaseReference = FirebaseDatabase.getInstance().getReference().child("Users")
                    .child(currentUser.id).child("userCategories").child(type)

                // Проверка на дублирование категории
                databaseReference.orderByChild("name").equalTo(categoryName)
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                            if (dataSnapshot.exists()) {
                                // Категория с таким именем уже существует
                                showToast("Категория с именем '$categoryName' уже существует")
                            } else {
                                // Категории с таким именем не существует, добавляем новую категорию
                                val categoryMap = mapOf("name" to categoryName, "iconResourceId" to imageId)
                                databaseReference.push().setValue(categoryMap)
                                showToast("Категория '$categoryName' успешно добавлена")

                                if (subcategoriesList.isNotEmpty()) {
                                    databaseReference.orderByChild("name").equalTo(categoryName)
                                        .addListenerForSingleValueEvent(object : ValueEventListener {
                                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                if (dataSnapshot.exists()) {
                                                    for (categorySnapshot in dataSnapshot.children) {
                                                        val subcategoriesRef = categorySnapshot.child("subcategories").ref
                                                        for (subcategoryName in subcategoriesList)
                                                            subcategoriesRef.push().setValue(subcategoryName)
                                                    }
                                                    showToast("Подкатегории успешно добавлены к категории '$categoryName'")
                                                } else {
                                                    showToast("Категория '$categoryName' не найдена")
                                                }
                                            }

                                            override fun onCancelled(databaseError: DatabaseError) {
                                                showToast("Ошибка при поиске категории '$categoryName': ${databaseError.message}")
                                            }
                                        })
                                }

                                finish()
                            }
                        }

                        override fun onCancelled(databaseError: DatabaseError) {
                            showToast("Ошибка при проверке существования категории: ${databaseError.message}")
                        }
                    })
            } else {
                showToast("Введите название категории")
            }
        } else {
            showToast("Пользователь не найден")
        }
    }


//    private fun addCategory(type: String) {
//        val currentUser = getCurrentUser()
//        if (currentUser != null) {
//            val categoryName = binding.etAddCategory.text.toString().trim()
//            val imageId = binding.selectImage.getTag() as? Int
//            if (categoryName.isNotEmpty()) {
//                val databaseReference = FirebaseDatabase.getInstance().getReference().child("Users")
//                    .child(currentUser.id).child("userCategories").child(type)
//
//                val categoryMap = mapOf("name" to categoryName, "iconResourceId" to imageId)
//                databaseReference.push().setValue(categoryMap)
//                showToast("Категория '$categoryName' успешно добавлена")
//
//                if (subcategoriesList.isNotEmpty()) {
//
//                    databaseReference.orderByChild("name").equalTo(categoryName).addListenerForSingleValueEvent(object : ValueEventListener {
//                        override fun onDataChange(dataSnapshot: DataSnapshot) {
//                            if (dataSnapshot.exists()) {
//                                for (categorySnapshot in dataSnapshot.children) {
//                                    val subcategoriesRef = categorySnapshot.child("subcategories").ref
//                                    for (subcategoryName in subcategoriesList)
//                                        subcategoriesRef.push().setValue(subcategoryName)
//                                }
//                                showToast("Подкатегории успешно добавлены к категории '$categoryName'")
//                            } else {
//                                showToast("Категория '$categoryName' не найдена")
//                            }
//                        }
//
//                        override fun onCancelled(databaseError: DatabaseError) {
//                            showToast("Ошибка при поиске категории '$categoryName': ${databaseError.message}")
//                        }
//                    })
//                }
//
//
//                finish()
//            } else {
//                showToast("Введите название категории")
//            }
//
//        } else {
//            showToast("Пользователь не найден")
//        }
//
//
//    }

    private fun addSubcategory() {
        val currentUser = getCurrentUser()
        if (currentUser != null) {
            val dialogView = layoutInflater.inflate(R.layout.dialog_add_subcategory, null)
            val builder = AlertDialog.Builder(this)
                .setView(dialogView)
                .create()

            val etSubcategoryName = dialogView.findViewById<EditText>(R.id.et_subcategory_name)
            val btnCancel = dialogView.findViewById<Button>(R.id.btn_cancel)
            val btnAdd = dialogView.findViewById<Button>(R.id.btn_add)

            builder.show()

            btnCancel.setOnClickListener {
                builder.dismiss()
            }

            // Обработка нажатия на положительную кнопку
            btnAdd.setOnClickListener {
                val subcategoryName = etSubcategoryName.text.toString().trim()
                if (subcategoryName.isNotEmpty()) {
                    if (!subcategoriesList.contains(subcategoryName)) {
                        subcategoriesList.add(subcategoryName)
                        subcategoryAdapter.notifyItemInserted(subcategoriesList.size - 1)
                        builder.dismiss() // Закрываем диалог только если подкатегория добавлена
                    } else {
                        showToast("Такая подкатегория уже существует")
                    }
                } else {
                    showToast("Введите название подкатегории")
                }
            }
        } else {
            showToast("Пользователь не найден")
        }
    }

    private fun getCurrentUser(): User? {
        val firebaseUser = auth.currentUser
        return if (firebaseUser != null) {
            User(id = firebaseUser.uid, username = "", email = "", userOperations = mutableListOf())
        } else {
            null
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }




    private inner class SubcategoryAdapter(
        private val subcategories: MutableList<String>
    ) : RecyclerView.Adapter<SubcategoryAdapter.SubcategoryViewHolder>() {

        private var onDeleteClickListener: ((Int) -> Unit)? = null

        fun setOnDeleteClickListener(listener: (Int) -> Unit) {
            onDeleteClickListener = listener
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubcategoryViewHolder {
            val binding = ItemSubcategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return SubcategoryViewHolder(binding)
        }

        override fun onBindViewHolder(holder: SubcategoryViewHolder, position: Int) {
            val subcategory = subcategories[position]
            holder.bind(subcategory, position)
        }

        override fun getItemCount(): Int = subcategories.size

        inner class SubcategoryViewHolder(private val binding: ItemSubcategoryBinding) :
            RecyclerView.ViewHolder(binding.root) {
            fun bind(subcategory: String, position: Int) {
                binding.subcategoryName.text = subcategory
                binding.subcategoryDelete.setOnClickListener {
                    onDeleteClickListener?.invoke(position)
                }
            }
        }
    }


    private inner class IconAdapter(
        private val icons: List<Int>
    ) : RecyclerView.Adapter<IconAdapter.IconViewHolder>() {

        private var onItemClick: ((Int) -> Unit)? = null

        fun setOnItemClickListener(listener: (Int) -> Unit) {
            onItemClick = listener
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IconViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.popup_icon, parent, false)
            return IconViewHolder(view)
        }

        override fun onBindViewHolder(holder: IconViewHolder, position: Int) {
            val icon = icons[position]
            holder.bind(icon)
        }

        override fun getItemCount(): Int = icons.size

        inner class IconViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            fun bind(icon: Int) {
                val imageView = itemView.findViewById<ImageView>(R.id.iconImageView)
                imageView.setImageResource(icon)

                // Обработка нажатия на иконку
                itemView.setOnClickListener {
                    onItemClick?.invoke(icon)
                }
            }
        }
    }
}
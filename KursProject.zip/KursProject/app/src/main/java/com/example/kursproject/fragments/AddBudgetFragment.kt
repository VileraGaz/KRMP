package com.example.kursproject.fragments

import android.app.DatePickerDialog
import android.content.res.Configuration
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.lifecycle.ViewModel
import com.example.kursproject.R
import com.example.kursproject.databinding.FragmentAddBudgetBinding
import com.example.kursproject.databinding.FragmentAddOperationBinding
import com.example.kursproject.tables.Budget
import com.example.kursproject.tables.Operation
import com.example.kursproject.tables.User
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddBudgetFragment : Fragment() {

    companion object {
        fun newInstance() = AddBudgetFragment()
    }

    private lateinit var viewModel: AddBudgetViewModel
    private lateinit var binding: FragmentAddBudgetBinding
    lateinit var auth: FirebaseAuth
    private  lateinit var selectedPeriod:String;

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAddBudgetBinding.inflate(inflater, container, false)
        auth = Firebase.auth
        // Первоначально установим категории расходов
        funOfShow("expenseCategories")
        binding.buttonAddBudget.setOnClickListener {
            addBudget()
            // Возвращение в BudgetFragment
            parentFragmentManager.popBackStack()
        }

        binding.back.setOnClickListener {
            // Возвращение в BudgetFragment
            parentFragmentManager.popBackStack()
        }

        val periodOptions = arrayOf("Неделя", "Месяц", "Год")
        val periodAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, periodOptions)
        periodAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerPeriod.adapter = periodAdapter

        val defaultDate = SimpleDateFormat("dd.MM.yyyy").format(System.currentTimeMillis())
        binding.editTextDate2.setText(defaultDate)

        binding.editTextDate2.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                showDatePickerDialog()
            }
        }

        binding.spinnerPeriod.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedPeriod = periodOptions[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Handle nothing selected if needed
            }
        }

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(AddBudgetViewModel::class.java)
        // TODO: Use the ViewModel
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val currentYear = calendar.get(Calendar.YEAR)
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentDay = calendar.get(Calendar.DAY_OF_MONTH)

        val locale = Locale("ru")
        Locale.setDefault(locale)
        val config = Configuration(resources.configuration)
        config.setLocale(locale)

        // Create a DatePickerDialog and set the initial date to the current date
        val datePickerDialog = DatePickerDialog(requireContext(), { view: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
            val selectedDateStr = SimpleDateFormat("dd.MM.yyyy").format(Calendar.getInstance().apply {
                set(Calendar.YEAR, year)
                set(Calendar.MONTH, month)
                set(Calendar.DAY_OF_MONTH, dayOfMonth)
            }.time)

            // Set the selected date in the editTextDate2 field
            binding.editTextDate2.setText(selectedDateStr)
        }, currentYear, currentMonth, currentDay)

        // Show the DatePickerDialog
        datePickerDialog.show()
    }

    private fun funOfShow(type : String){
        val currentUser = getCurrentUser()

        currentUser?.id?.let { userId ->
            val databaseReference = FirebaseDatabase.getInstance().getReference().child("Users")
                .child(userId).child("userCategories").child(type)
            changeTypeOfCategory(binding, databaseReference)
        }
    }

    private fun changeTypeOfCategory(binding: FragmentAddBudgetBinding, categoriesReference: DatabaseReference) {
        categoriesReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val categoryNames = mutableListOf<String>()
                for (categorySnapshot in dataSnapshot.children) {
                    val categoryName = categorySnapshot.child("name").getValue(String::class.java)
                    categoryName?.let {
                        categoryNames.add(it)
                    }
                }
                val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categoryNames)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.spinnerCategoryBudget.adapter = adapter
                categoryNames.add(0, "Все категории")  // Добавляем новое значение в начало списка
                adapter.notifyDataSetChanged()     // Уведомляем адаптер об изменении данных
                binding.spinnerCategoryBudget.setSelection(0) // Устанавливаем новую запись как выбранную
            }

            override fun onCancelled(databaseError: DatabaseError) {
            }
        })
    }

    private fun addBudget() {
        val database = Firebase.database
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        val userBudgetRef = database.getReference("Users/$userId/Budget")
        val sum = binding.editTextSum.text.toString().toDouble()
        val category = binding.spinnerCategoryBudget.selectedItem.toString()
        val startDate = binding.editTextDate2.text.toString()

        val calendar = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("dd.MM.yyyy")
        calendar.time = dateFormat.parse(startDate)

        // В зависимости от выбранного периода добавляем соответствующий интервал к дате окончания
        val selectedPeriodInMilliseconds = when (selectedPeriod) {
            "Неделя" -> {
                Calendar.WEEK_OF_YEAR
            }
            "Месяц" -> {
                Calendar.MONTH
            }
            "Год" -> {
                Calendar.YEAR
            }
            else -> Calendar.DATE
        }
        calendar.add(selectedPeriodInMilliseconds, 1)
        val endDate = calendar.timeInMillis

        // Получаем текущего пользователя
        val currentUser = getCurrentUser()

        // Создаем объект операции
        val budget = Budget(
            sum = sum,
            category = category,
            startDate = dateFormat.parse(startDate)?.time ?: 0,
            endDate = endDate
        )

        // Добавляем операцию к пользователю
        currentUser?.addBudget(budget)

        // Обновляем данные в базе данных или хранилище

        val newBudgetRef = userBudgetRef.push()
        newBudgetRef.setValue(budget)

        // Опционально: обновляем интерфейс
    }


    private fun getCurrentUser(): User? {
        val firebaseUser = auth.currentUser // Получаем текущего пользователя Firebase
        return if (firebaseUser != null) {
            // Пользователь аутентифицирован, возвращаем объект User с категориями по умолчанию
            User(id = firebaseUser.uid,
                username = "",
                email = "",
                userOperations = mutableListOf()) // Передаем пустые значения для username и email
        } else {
            // Пользователь не аутентифицирован, возвращаем null или выполняем необходимые действия
            null
        }
    }
}

class AddBudgetViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
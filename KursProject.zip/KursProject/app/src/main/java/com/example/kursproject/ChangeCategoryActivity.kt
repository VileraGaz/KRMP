package com.example.kursproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kursproject.databinding.ActivityAddCategoryBinding
import com.example.kursproject.databinding.ItemCategoryBinding
import com.example.kursproject.databinding.ItemSubcategoryBinding
import com.example.kursproject.tables.User
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ChangeCategoryActivity : AppCompatActivity() {

    lateinit var auth: FirebaseAuth
    lateinit var binding: ActivityAddCategoryBinding
    private lateinit var subcategoryAdapter: ChangeCategoryActivity.SubcategoryAdapter
    private var subcategoriesList = mutableListOf<String>()
    private var currentCategoryName: String = "" // Переменная для хранения текущего названия категории
    private val iconList = listOf(
        R.drawable.bus, R.drawable.food, R.drawable.funny,
        R.drawable.gift, R.drawable.health, R.drawable.home, R.drawable.invest,
        R.drawable.shirt, R.drawable.sport, R.drawable.salary
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddCategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        val category = intent.getStringExtra("categoryName")
        currentCategoryName = category ?: ""
        subcategoriesList = intent.getStringArrayListExtra("subcategories")?.toMutableList() ?: mutableListOf()
        val imageId = intent.getIntExtra("categoryImageId", R.drawable.food)

        val type = intent.getStringExtra("type") ?: ""

        binding.categoryHead.text = "Категория"
        binding.btnAddCategory.text = "Сохранить"
        binding.etAddCategory.text = Editable.Factory.getInstance().newEditable(category.toString())
        binding.selectImage.setImageResource(imageId)

        binding.tvSubcategories.visibility = View.VISIBLE
        binding.rvSubcategories.visibility = View.VISIBLE

        binding.btnAddCategory.setOnClickListener{
            changeCategory(type)
            updateSubcategoriesInDB(type)
        }

        binding.btnAddSubcategory.setOnClickListener{
            addSubcategory(subcategoriesList)
        }

        subcategoryAdapter = SubcategoryAdapter(subcategoriesList)
        binding.rvSubcategories.adapter = subcategoryAdapter
        binding.rvSubcategories.layoutManager = LinearLayoutManager(this)

        subcategoryAdapter.setOnDeleteClickListener { position ->
            subcategoriesList.removeAt(position)
            subcategoryAdapter.notifyItemRemoved(position)
        }

        binding.selectImage.setOnClickListener {
            val popupView = layoutInflater.inflate(R.layout.popup_bubble, null)

            // Инициализация RecyclerView внутри PopupWindow
            val popupRecyclerView = popupView.findViewById<RecyclerView>(R.id.recyclerViewIcons)
            val layoutManager = GridLayoutManager(this@ChangeCategoryActivity, 3)
            popupRecyclerView.layoutManager = layoutManager
            val iconAdapter = IconAdapter(iconList)
            popupRecyclerView.adapter = iconAdapter

            // Создание PopupWindow
            val width = ViewGroup.LayoutParams.WRAP_CONTENT
            val height = ViewGroup.LayoutParams.WRAP_CONTENT
            val focusable = true // Позволяет PopupWindow закрываться при нажатии вне его области
            val popupWindow = PopupWindow(popupView, width, height, focusable)

            // Показ PopupWindow в окне с фокусом
            popupWindow.showAtLocation(binding.root, Gravity.CENTER_HORIZONTAL, 0, -100)


            // Обработка выбора иконки
            iconAdapter.setOnItemClickListener { selectedIcon ->
                // Установка выбранной иконки в selectImage
                binding.selectImage.setImageResource(selectedIcon)
                binding.selectImage.setTag(selectedIcon)
                // Закрытие PopupWindow
                popupWindow.dismiss()
            }
        }

        binding.OKbtn.setOnClickListener{
            finish()
        }

    }

    private fun changeCategory(type: String) {
        val currentUser = getCurrentUser()
        if (currentUser != null) {
            val newCategoryName = binding.etAddCategory.text.toString().trim()
            val newImageId = binding.selectImage.getTag() as? Int ?: R.drawable.food
            if (newCategoryName.isNotEmpty()) {
                val oldCategoryName = currentCategoryName // Сохраняем текущее название категории перед обновлением
                currentCategoryName = newCategoryName // Обновляем текущее название категории

                val databaseReference = FirebaseDatabase.getInstance().getReference().child("Users")
                    .child(currentUser.id).child("userCategories").child(type)

                // Используем текущее название категории для поиска в базе данных
                databaseReference.orderByChild("name").equalTo(oldCategoryName)
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                            if (dataSnapshot.exists()) {
                                for (categorySnapshot in dataSnapshot.children) {
                                    val currentImageId = categorySnapshot.child("iconResourceId").getValue(Int::class.java) ?: R.drawable.food
                                    if (oldCategoryName != newCategoryName)
                                        categorySnapshot.ref.child("name").setValue(newCategoryName)
                                    if (currentImageId != newImageId)
                                        categorySnapshot.ref.child("iconResourceId").setValue(newImageId)
                                }
                                showToast("Категория успешно изменена")
                            } else {
                                showToast("Категория '$oldCategoryName' не найдена")
                            }
                        }

                        override fun onCancelled(databaseError: DatabaseError) {
                            showToast("Ошибка при поиске категории '$oldCategoryName': ${databaseError.message}")
                        }
                    })
            } else {
                showToast("Введите новое название категории")
            }
        } else {
            showToast("Пользователь не найден")
        }
    }


    private fun updateSubcategoriesInDB(type: String) {
        val currentUser = getCurrentUser()
        if (currentUser != null) {
            val categoryName = binding.etAddCategory.text.toString().trim()
            if (categoryName.isNotEmpty()) {
                val databaseReference = FirebaseDatabase.getInstance().getReference().child("Users")
                    .child(currentUser.id).child("userCategories").child(type)

                databaseReference.orderByChild("name").equalTo(categoryName)
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                            if (dataSnapshot.exists()) {
                                for (categorySnapshot in dataSnapshot.children) {
                                    val subcategoriesRef = categorySnapshot.child("subcategories").ref

                                    subcategoriesRef.addListenerForSingleValueEvent(object : ValueEventListener {
                                        override fun onDataChange(subcategorySnapshot: DataSnapshot) {
                                            val currentSubcategories = mutableListOf<String>()
                                            for (sub in subcategorySnapshot.children) {
                                                val subcategoryName = sub.getValue(String::class.java)
                                                if (subcategoryName != null) {
                                                    currentSubcategories.add(subcategoryName)
                                                }
                                            }

                                            val toAdd = subcategoriesList.filter { it !in currentSubcategories }
                                            val toRemove = currentSubcategories.filter { it !in subcategoriesList }

                                            toRemove.forEach { subcategory ->
                                                subcategoriesRef.orderByValue().equalTo(subcategory)
                                                    .addListenerForSingleValueEvent(object : ValueEventListener {
                                                        override fun onDataChange(snapshot: DataSnapshot) {
                                                            for (subSnap in snapshot.children) {
                                                                subSnap.ref.removeValue()
                                                            }
                                                        }

                                                        override fun onCancelled(error: DatabaseError) {}
                                                    })
                                            }

                                            toAdd.forEach { subcategory ->
                                                subcategoriesRef.push().setValue(subcategory)
                                            }

                                            showToast("Подкатегории успешно обновлены для категории '$categoryName'")
                                        }

                                        override fun onCancelled(error: DatabaseError) {
                                            showToast("Ошибка при обновлении подкатегорий: ${error.message}")
                                        }
                                    })
                                }
                            } else {
                                showToast("Категория '$categoryName' не найдена")
                            }
                        }

                        override fun onCancelled(databaseError: DatabaseError) {
                            showToast("Ошибка при поиске категории '$categoryName': ${databaseError.message}")
                        }
                    })
            } else {
                showToast("Введите название категории")
            }
        } else {
            showToast("Пользователь не найден")
        }
    }

    private fun addSubcategory(subcategoriesList: MutableList<String>) {
        val currentUser = getCurrentUser()
        if (currentUser != null) {
            val dialogView = layoutInflater.inflate(R.layout.dialog_add_subcategory, null)
            val builder = AlertDialog.Builder(this)
                .setView(dialogView)
                .create()

            val etSubcategoryName = dialogView.findViewById<EditText>(R.id.et_subcategory_name)
            val btnCancel = dialogView.findViewById<Button>(R.id.btn_cancel)
            val btnAdd = dialogView.findViewById<Button>(R.id.btn_add)

            builder.show()

            btnCancel.setOnClickListener {
                builder.dismiss()
            }

            btnAdd.setOnClickListener {
                val subcategoryName = etSubcategoryName.text.toString().trim()
                if (subcategoryName.isNotEmpty()) {
                    if (!subcategoriesList.contains(subcategoryName)) {
                        subcategoriesList.add(subcategoryName)
                        subcategoryAdapter.notifyItemInserted(subcategoriesList.size - 1)
                        builder.dismiss() // Закрываем диалог только если подкатегория добавлена
                    } else {
                        showToast("Такая подкатегория уже существует")
                    }
                } else {
                    showToast("Введите название подкатегории")
                }
            }
        } else {
            showToast("Пользователь не найден")
        }
    }


//    private fun addSubcategory(subcategoriesList: MutableList<String>) {
//        val currentUser = getCurrentUser()
//        if (currentUser != null) {
//            val builder = AlertDialog.Builder(this)
//            builder.setTitle("Добавить подкатегорию")
//
//            val input = EditText(this)
//            input.hint = "Введите название подкатегории"
//            builder.setView(input)
//
//            builder.setPositiveButton("Добавить", null) // Устанавливаем null для автоматического закрытия диалога
//            builder.setNegativeButton("Отмена") { dialog, _ ->
//                dialog.dismiss()
//            }
//
//            val dialog = builder.create()
//            dialog.show()
//
//            // Обработка нажатия на положительную кнопку
//            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
//                val subcategoryName = input.text.toString().trim()
//                if (subcategoryName.isNotEmpty()) {
//                    if (!subcategoriesList.contains(subcategoryName)) {
//                        subcategoriesList.add(subcategoryName)
//                        subcategoryAdapter.notifyItemInserted(subcategoriesList.size - 1)
//                        dialog.dismiss() // Закрываем диалог только если подкатегория добавлена
//                    } else {
//                        showToast("Такая подкатегория уже существует")
//                    }
//                } else {
//                    showToast("Введите название подкатегории")
//                }
//            }
//        } else {
//            showToast("Пользователь не найден")
//        }
//    }


    private fun getCurrentUser(): User? {
        val firebaseUser = auth.currentUser
        return if (firebaseUser != null) {
            User(id = firebaseUser.uid, username = "", email = "", userOperations = mutableListOf())
        } else {
            null
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }



    private inner class SubcategoryAdapter(
        private val subcategories: MutableList<String>
    ) : RecyclerView.Adapter<SubcategoryAdapter.SubcategoryViewHolder>() {

        private var onDeleteClickListener: ((Int) -> Unit)? = null

        fun setOnDeleteClickListener(listener: (Int) -> Unit) {
            onDeleteClickListener = listener
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubcategoryViewHolder {
            val binding = ItemSubcategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return SubcategoryViewHolder(binding)
        }

        override fun onBindViewHolder(holder: SubcategoryViewHolder, position: Int) {
            val subcategory = subcategories[position]
            holder.bind(subcategory, position)
        }

        override fun getItemCount(): Int = subcategories.size

        inner class SubcategoryViewHolder(private val binding: ItemSubcategoryBinding) :
            RecyclerView.ViewHolder(binding.root) {
            fun bind(subcategory: String, position: Int) {
                binding.subcategoryName.text = subcategory
                binding.subcategoryDelete.setOnClickListener {
                    onDeleteClickListener?.invoke(position)
                }
            }
        }
    }


    private inner class IconAdapter(
        private val icons: List<Int>
    ) : RecyclerView.Adapter<IconAdapter.IconViewHolder>() {

        private var onItemClick: ((Int) -> Unit)? = null

        fun setOnItemClickListener(listener: (Int) -> Unit) {
            onItemClick = listener
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IconViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.popup_icon, parent, false)
            return IconViewHolder(view)
        }

        override fun onBindViewHolder(holder: IconViewHolder, position: Int) {
            val icon = icons[position]
            holder.bind(icon)
        }

        override fun getItemCount(): Int = icons.size

        inner class IconViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            fun bind(icon: Int) {
                val imageView = itemView.findViewById<ImageView>(R.id.iconImageView)
                imageView.setImageResource(icon)

                // Обработка нажатия на иконку
                itemView.setOnClickListener {
                    onItemClick?.invoke(icon)
                }
            }
        }
    }
}
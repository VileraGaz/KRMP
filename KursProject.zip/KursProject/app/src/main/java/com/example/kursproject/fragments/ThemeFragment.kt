package com.example.kursproject.fragments

import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Icon
import android.os.Build
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModel
import androidx.navigation.fragment.findNavController
import androidx.preference.PreferenceManager
import com.example.kursproject.R
import com.example.kursproject.databinding.FragmentSettingsBinding
import com.example.kursproject.databinding.FragmentThemeBinding

class ThemeFragment : Fragment() {

    private lateinit var sharedPreferences: SharedPreferences
    lateinit var binding: FragmentThemeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val navController = findNavController()
        binding = FragmentThemeBinding.inflate(inflater, container, false)

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(requireContext())

        binding.systemThemeSwitch.isChecked = sharedPreferences.getBoolean("use_system_theme", true)
        binding.themeRadioGroup.visibility = if (binding.systemThemeSwitch.isChecked) View.GONE else View.VISIBLE

        val currentTheme = sharedPreferences.getString("app_theme", "system")
        when (currentTheme) {
            "light" -> binding.lightThemeRadioButton.isChecked = true
            "dark" -> binding.darkThemeRadioButton.isChecked = true
        }

        // Switch listener
        binding.systemThemeSwitch.setOnCheckedChangeListener { _, isChecked ->
            binding.themeRadioGroup.visibility = if (isChecked) View.GONE else View.VISIBLE
            sharedPreferences.edit().putBoolean("use_system_theme", isChecked).apply()
            applyTheme()
        }

        // RadioGroup listener
        binding.themeRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            val selectedTheme = when (checkedId) {
                R.id.light_theme_radio_button -> "light"
                R.id.dark_theme_radio_button -> "dark"
                else -> "system"
            }
            sharedPreferences.edit().putString("app_theme", selectedTheme).apply()
            applyTheme()
        }

        binding.OKbtn.setOnClickListener {
            navController.navigate(R.id.action_themeFragment_to_settingsFragment)
        }

        return binding.root
    }



    private fun applyTheme() {
        val useSystemTheme = sharedPreferences.getBoolean("use_system_theme", true)
        val theme = if (useSystemTheme) {
            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        } else {
            when (sharedPreferences.getString("app_theme", "system")) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        }
        AppCompatDelegate.setDefaultNightMode(theme)
    }
}

class ThemeViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
package com.example.kursproject.fragments

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.db.williamchart.view.DonutChartView
import com.example.kursproject.R
import com.example.kursproject.databinding.FragmentAnalyticsBinding
import com.example.kursproject.databinding.ItemCategoryAnalyticsBinding
import com.example.kursproject.tables.Operation
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.google.common.io.Resources
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Calendar

class AnalyticsFragment : Fragment() {


    private lateinit var viewModel: AnalyticsViewModel
    private lateinit var binding: FragmentAnalyticsBinding
    private var selectedPeriod = "Текущий месяц"
    private var type = true
    private var totalIncomeForPeriod = 0.0
    private var totalExpenseForPeriod = 0.0
    private var totalInc = 0.0
    private var totalExp = 0.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentAnalyticsBinding.inflate(inflater, container, false)

        setupTimeRangeSpinner()

//        val incomeTextView = binding.income
//        val expenseTextView = binding.expense

        binding.btnConsumption.setOnClickListener {
            type = true
            binding.btnConsumption.setBackgroundColor(Color.parseColor("#2080EE"))
            binding.btnIncome.setBackgroundColor(Color.parseColor("#F7F7F9"))
            binding.btnConsumption.setTextColor(Color.parseColor("#F7F7F9"))
            binding.btnIncome.setTextColor(Color.parseColor("#2080EE"))
//            incomeTextView.text = totalIncome.toString()
//            expenseTextView.text = totalExpense.toString()
            fetchData(selectedPeriod) // Re-fetch data based on the selected type
        }

        binding.btnIncome.setOnClickListener {
            type = false
            binding.btnIncome.setBackgroundColor(Color.parseColor("#2080EE"))
            binding.btnConsumption.setBackgroundColor(Color.parseColor("#F7F7F9"))
            binding.btnIncome.setTextColor(Color.parseColor("#F7F7F9"))
            binding.btnConsumption.setTextColor(Color.parseColor("#2080EE"))
//            incomeTextView.text = totalIncome.toString()
//            expenseTextView.text = totalExpense.toString()
            fetchData(selectedPeriod) // Re-fetch data based on the selected type
        }

        setupTimeRangeSpinner()

        return binding.root
    }

    private fun Double.formatAmountWithCurrency(currencySymbol: String): String {
        val formattedAmount = if (this == this.toLong().toDouble()) {
            String.format("%.0f", this)
        } else {
            String.format("%.2f", this)
        }
        return "$formattedAmount $currencySymbol"
    }

    private fun setupTimeRangeSpinner() {
        binding.timeRangeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                selectedPeriod = parent.getItemAtPosition(position) as String
                fetchData(selectedPeriod)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun fetchData(selectedPeriod: String) {
        val incomeTextView = binding.income
        val expenseTextView = binding.expense

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val userId = FirebaseAuth.getInstance().currentUser?.uid
                val operationReference = FirebaseDatabase.getInstance().getReference("Users/$userId/Operations")
                operationReference.addListenerForSingleValueEvent(object : ValueEventListener {
                    @RequiresApi(Build.VERSION_CODES.O)
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        val sumMap = mutableMapOf<String, Double>()
                        totalIncomeForPeriod = 0.0
                        totalExpenseForPeriod = 0.0
                        totalInc = 0.0
                        totalExp = 0.0

                        val (startDate, endDate) = when (selectedPeriod) {
                            "Текущая неделя" -> {
                                val today = LocalDate.now(ZoneId.systemDefault())
                                val startOfWeek = today.with(DayOfWeek.MONDAY)
                                val endOfWeek = startOfWeek.plusDays(6)
                                Pair(startOfWeek, endOfWeek)
                            }
                            "Текущий месяц" -> {
                                val startOfMonth = LocalDate.now(ZoneId.systemDefault()).withDayOfMonth(1)
                                val endOfMonth = startOfMonth.withDayOfMonth(startOfMonth.lengthOfMonth())
                                Pair(startOfMonth, endOfMonth)
                            }
                            "Текущий год" -> {
                                val startOfYear = LocalDate.now(ZoneId.systemDefault()).withDayOfYear(1)
                                val endOfYear = startOfYear.withDayOfYear(startOfYear.lengthOfYear())
                                Pair(startOfYear, endOfYear)
                            }
                            else -> {
                                val startOfMonth = LocalDate.now(ZoneId.systemDefault()).withDayOfMonth(1)
                                val endOfMonth = startOfMonth.withDayOfMonth(startOfMonth.lengthOfMonth())
                                Pair(startOfMonth, endOfMonth)
                            }
                        }

                        val categorySums = mutableMapOf<String, Pair<Double, Int>>() // Map to store sum and iconResourceId
                        for (operationSnapshot in dataSnapshot.children) {
                            val amount = operationSnapshot.child("amount").getValue(Double::class.java) ?: 0.0
                            val date = operationSnapshot.child("date").getValue(Long::class.java) ?: 0L
                            val operationDate = Instant.ofEpochMilli(date).atZone(ZoneId.systemDefault()).toLocalDate()
                            val iconResourceId = operationSnapshot.child("iconResourceId").getValue(Int::class.java) ?: R.drawable.food

                            val operation = Operation(
                                operationSnapshot.child("type").getValue(Boolean::class.java) ?: false,
                                amount,
                                date,
                                operationSnapshot.child("category_expense").getValue(String::class.java) ?: "",
                                operationSnapshot.child("category_income").getValue(String::class.java) ?: "",
                                operationSnapshot.child("subcategory").getValue(String::class.java) ?: "",
                                iconResourceId
                            )

                            if (shouldIncludeOperation(operation, startDate, endDate, type)) {
                                if (!operation.type) {
                                    totalIncomeForPeriod += amount
                                    val category = operation.category_income
                                    categorySums[category] = Pair(
                                        (categorySums[category]?.first ?: 0.0) + amount,
                                        iconResourceId
                                    )
                                } else {
                                    totalExpenseForPeriod += amount
                                    val category = operation.category_expense
                                    categorySums[category] = Pair(
                                        (categorySums[category]?.first ?: 0.0) + amount,
                                        iconResourceId
                                    )
                                }

                                val key = getKey(operationDate, selectedPeriod)
                                val currentSum = sumMap[key] ?: 0.0
                                sumMap[key] = currentSum + amount
                            }

                            if (shouldIncludeOperation(operation, startDate, endDate, false)) {
                                if (!operation.type)
                                    totalInc += amount
                            }

                            if (shouldIncludeOperation(operation, startDate, endDate, true)) {
                                if (operation.type)
                                    totalExp += amount
                            }

                        }

                        val allKeys = getAllKeys(startDate, endDate, selectedPeriod)
//                        if (selectedPeriod == "Текущий месяц") Log.d("all", allKeys.toString()) // ПРОБЛЕМА В ОСИ
                        allKeys.forEach { key ->
                            sumMap.putIfAbsent(key, 0.0)
                        }

                        val maxSum = sumMap.values.maxOrNull() ?: 0.0

                        val percentageMap = sumMap.mapValues { (it.value / maxSum) * 100 }
                        val sortedPercentageList = percentageMap.toList().sortedBy { it.first.toInt() }
                        val barSet = sortedPercentageList.map { (key, percentage) ->
                            getAbbreviation(key, selectedPeriod) to percentage.toFloat()
                        }

                        requireActivity().runOnUiThread {
                            binding.income.text = totalInc.formatAmountWithCurrency("₽")
                            binding.expense.text = totalExp.formatAmountWithCurrency("₽")

                            val colors = mutableListOf<Int>()

                            val step = (60 - 0) / percentageMap.size
                            for (i in 0 until percentageMap.size) {
                                val hue = (i * step) % 360
                                val color = ColorUtils.HSLToColor(floatArrayOf(hue.toFloat(), 0.7f, 0.8f))
                                colors.add(color)
                            }

                            binding.barChart.barsColorsList = colors
                            binding.barChart.animate(barSet)
                            binding.barChart.labelsSize = 30.0f

                            val pieEntries = categorySums.map { PieEntry(it.value.first.toFloat(), it.key) }

                            val colorsPC = categorySums.keys.map { key ->
                                val hue = key.hashCode() % 360
                                ColorUtils.HSLToColor(
                                    floatArrayOf(
                                        hue.toFloat(),
                                        0.7f,
                                        0.8f
                                    )
                                )
                            }


                            val pieDataSet = PieDataSet(pieEntries, "Categories")
                            pieDataSet.colors = colorsPC
                            pieDataSet.setDrawValues(false)  // Скрыть цифры на пончике
                            val pieData = PieData(pieDataSet)

                            binding.pieChart.data = pieData
                            binding.pieChart.setHoleColor(Color.TRANSPARENT)
                            binding.pieChart.setDrawEntryLabels(false)  // Скрыть надписи на пончике
                            binding.pieChart.description.isEnabled = false  // Убрать "description label"
                            binding.pieChart.legend.isEnabled = false  // Скрыть легенду
                            binding.pieChart.invalidate()
                            binding.pieChart.animateY(1000)

                            val totalSum = categorySums.values.sumOf { it.first }
                            val categoryItems = categorySums.toList().mapIndexed { index, entry ->
                                val percentage = (entry.second.first / totalSum * 100)
                                CategoryItem(entry.first, entry.second.first.toFloat(), colorsPC[index], percentage.toFloat(), entry.second.second)
                            }

                            val adapter = CategoryAdapter(categoryItems)
                            binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
                            binding.recyclerView.adapter = adapter
                        }
                    }

                    override fun onCancelled(databaseError: DatabaseError) {
                    }
                })
            } catch (e: Exception) {
                // Обработка исключений, если необходимо
            }
        }
    }



    @RequiresApi(Build.VERSION_CODES.O)
    private fun shouldIncludeOperation(operation: Operation, startDate: LocalDate, endDate: LocalDate, type: Boolean): Boolean {
        val operationDate = Instant.ofEpochMilli(operation.date).atZone(ZoneId.systemDefault()).toLocalDate()

        val isInSelectedPeriod = operationDate in startDate..endDate

        return if (type) {
            operation.type && operation.category_expense.isNotEmpty() && isInSelectedPeriod
        } else {
            !operation.type && operation.category_income.isNotEmpty() && isInSelectedPeriod
        }
    }


    @RequiresApi(Build.VERSION_CODES.O)
    private fun getKey(date: LocalDate, selectedPeriod: String): String {
        return when (selectedPeriod) {
            "Текущая неделя" -> date.dayOfWeek.value.toString()
            "Текущий месяц" -> date.dayOfMonth.toString()
            "Текущий год" -> date.monthValue.toString()
            else -> ""
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun getAllKeys(startDate: LocalDate, endDate: LocalDate, selectedPeriod: String): List<String> {
        return when (selectedPeriod) {
            "Текущая неделя" -> (1..7).map { it.toString() }

            "Текущий месяц" -> (1..endDate.dayOfMonth).filter { it % 2 != 0 }.map { it.toString() } // Внестри правки

            "Текущий год" -> (1..12).map { it.toString() }
            else -> emptyList()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun getAbbreviation(key: String, selectedPeriod: String): String {
        return when (selectedPeriod) {
            "Текущая неделя" -> getWeekDayAbbreviation(key)
            "Текущий месяц" -> key
            "Текущий год" -> getMonthAbbreviation(key)
            else -> ""
        }
    }


    private fun getMonthAbbreviation(month: String): String {
        return when (month.toIntOrNull()) {
            1 -> "Я"
            2 -> "Ф"
            3 -> "М"
            4 -> "А"
            5 -> "М"
            6 -> "И"
            7 -> "И"
            8 -> "А"
            9 -> "С"
            10 -> "О"
            11 -> "Н"
            12 -> "Д"
            else -> "N/A"
        }
    }

    private fun getWeekDayAbbreviation(dayOfWeek: String): String {
        return when (dayOfWeek.toIntOrNull()) {
            1 -> "Пн" // Понедельник
            2 -> "Вт" // Вторник
            3 -> "Ср" // Среда
            4 -> "Чт" // Четверг
            5 -> "Пт" // Пятница
            6 -> "Сб" // Суббота
            7 -> "Вс" // Воскресенье
            else -> "N/A"
        }
    }

    data class CategoryItem(val name: String, val sum: Float, val color: Int, val percentage: Float, val iconResourceId: Int)

    class CategoryAdapter(private val items: List<CategoryItem>) :
        RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

        class CategoryViewHolder(val binding: ItemCategoryAnalyticsBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
            val binding = ItemCategoryAnalyticsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return CategoryViewHolder(binding)
        }

        override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
            val item = items[position]
            holder.binding.apply {
                imageViewCat.setImageResource(item.iconResourceId)
                categoryName.text = item.name
                categorySum.text = item.sum.toString()
                categoryProgress.progress = item.percentage.toInt()
                categoryProgress.progressTintList = ColorStateList.valueOf(item.color)

                val percentageText = if (item.percentage % 1 == 0f) {
                    item.percentage.toInt().toString()
                } else {
                    String.format("%.1f", item.percentage)
                }
                sumProcent.text = percentageText
            }
        }

        override fun getItemCount(): Int = items.size
    }

}

class AnalyticsViewModel : ViewModel() {
    var isConsumptionSelected: Boolean = true
    var selectedPeriod: String = "Текущий месяц"
}

package com.example.kursproject.fragments

import android.Manifest
import android.app.DatePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.kursproject.R
import com.example.kursproject.databinding.FragmentExcelBinding
import com.example.kursproject.tables.Operation
import com.google.android.material.datepicker.CalendarConstraints
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.*

class Excel : Fragment() {

    companion object {
        private const val WRITE_EXTERNAL_STORAGE_REQUEST_CODE = 101
        fun newInstance() = Excel()
    }

    private lateinit var viewModel: ExcelViewModel
    private lateinit var binding: FragmentExcelBinding
    private val userId = FirebaseAuth.getInstance().currentUser?.uid

    private var selectedType: String = "Все"
    private var selectedPeriod: String = "За все время"
    private var startDate: LocalDate? = null
    private var endDate: LocalDate? = null

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentExcelBinding.inflate(inflater, container, false)
        val navController = findNavController()

        setupSpinners()
        setupDatePickers()

        binding.OKbtn.setOnClickListener {
            navController.navigate(R.id.action_excel_to_settingsFragment2)
        }

        binding.buttonExcel.setOnClickListener {
            Log.d("ExcelFragment", "Button clicked")
            if (ContextCompat.checkSelfPermission(
                    requireActivity(),
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                Log.d("ExcelFragment", "Permission not granted, requesting permission")
                ActivityCompat.requestPermissions(
                    requireActivity(),
                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    WRITE_EXTERNAL_STORAGE_REQUEST_CODE
                )
            } else {
                Log.d("ExcelFragment", "Permission already granted, fetching operations")
                if (userId != null) {
                    fetchOperations(userId)
                }
            }
        }

        return binding.root
    }

    private fun setupSpinners() {
        binding.spnType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                selectedType = parent.getItemAtPosition(position) as String
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        binding.spnPeriod.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                selectedPeriod = parent.getItemAtPosition(position) as String
                if (selectedPeriod == "Выбрать период") {
                    binding.editTextStartDate.visibility = View.VISIBLE
                    binding.editTextEndDate.visibility = View.VISIBLE
                } else {
                    binding.editTextStartDate.visibility = View.GONE
                    binding.editTextEndDate.visibility = View.GONE
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setupDatePickers() {
        binding.editTextStartDate.setOnClickListener {
            showDatePicker { date ->
                startDate = date
                binding.editTextStartDate.setText(date.toString())
            }
        }

        binding.editTextEndDate.setOnClickListener {
            showDatePicker { date ->
                endDate = date
                binding.editTextEndDate.setText(date.toString())
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun showDatePicker(onDateSelected: (LocalDate) -> Unit) {
        val calendar = Calendar.getInstance()
        val datePickerDialog = DatePickerDialog(requireContext(), { _, year, month, dayOfMonth ->
            val selectedDate = LocalDate.of(year, month + 1, dayOfMonth)
            onDateSelected(selectedDate)
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
        datePickerDialog.show()
    }

    private fun fetchOperations(userId: String) {
        val databaseReference = FirebaseDatabase.getInstance().getReference("Users/$userId/Operations")
        val operations = mutableListOf<Operation>()
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (operationSnapshot in dataSnapshot.children) {
                    val amount = operationSnapshot.child("amount").getValue(Double::class.java) ?: 0.0
                    val categoryExpense = operationSnapshot.child("category_expense").getValue(String::class.java) ?: ""
                    val categoryIncome = operationSnapshot.child("category_income").getValue(String::class.java) ?: ""
                    val subcategory = operationSnapshot.child("subcategory").getValue(String::class.java) ?: ""
                    val date = operationSnapshot.child("date").getValue(Long::class.java) ?: 0L
                    val type = operationSnapshot.child("type").getValue(Boolean::class.java) ?: false
                    val iconResourceId = operationSnapshot.child("iconResourceId").getValue(Int::class.java) ?: 0

                    val operation = Operation(type, amount, date, categoryExpense, categoryIncome, subcategory, iconResourceId)
                    if (shouldIncludeOperation(operation)) {
                        operations.add(operation)
                    }
                }
                operations.sortByDescending { it.date }
                createExcelFile(operations)
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.e("Firebase", "Error fetching data", databaseError.toException())
            }
        })
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun shouldIncludeOperation(operation: Operation): Boolean {
        val operationDate = Instant.ofEpochMilli(operation.date).atZone(ZoneId.systemDefault()).toLocalDate()

        // Фильтрация по типу операции
        if (selectedType != "Все" && ((selectedType == "Расход" && !operation.type) || (selectedType == "Доход" && operation.type))) {
            return false
        }

        // Фильтрация по периоду времени
        return when (selectedPeriod) {
            "За все время" -> true
            "Текущая неделя" -> {
                val startOfWeek = LocalDate.now().with(DayOfWeek.MONDAY)
                val endOfWeek = LocalDate.now().with(DayOfWeek.SUNDAY)
                operationDate in startOfWeek..endOfWeek
            }
            "Текущий месяц" -> {
                val startOfMonth = LocalDate.now().withDayOfMonth(1)
                val endOfMonth = LocalDate.now().withDayOfMonth(LocalDate.now().lengthOfMonth())
                operationDate in startOfMonth..endOfMonth
            }
            "Текущий год" -> {
                val startOfYear = LocalDate.now().withDayOfYear(1)
                val endOfYear = LocalDate.now().withDayOfYear(LocalDate.now().lengthOfYear())
                operationDate in startOfYear..endOfYear
            }
            "Выбрать период" -> {
                if (startDate != null && endDate != null) {
                    operationDate in startDate!!..endDate!!
                } else {
                    true
                }
            }
            else -> true
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createExcelFile(operations: List<Operation>) {
        val workbook = HSSFWorkbook()
        val currentDate: LocalDate = LocalDate.now()
        val formatter = DateTimeFormatter.ofPattern("ddMMyyyy")
        val formattedDate: String = currentDate.format(formatter)

        val sheet = workbook.createSheet("Sheet1")

        val headerRow = sheet.createRow(0)
        val headers = arrayOf("Дата", "Категория", "Подкатегория", "Сумма")
        for (i in headers.indices) {
            val cell = headerRow.createCell(i)
            cell.setCellValue(headers[i])
        }

        val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

        for ((index, operation) in operations.withIndex()) {
            val dataRow = sheet.createRow(index + 1)

            val dateCell = dataRow.createCell(0)
            val date = Instant.ofEpochMilli(operation.date).atZone(ZoneId.systemDefault()).toLocalDate()
            dateCell.setCellValue(date.format(dateFormatter))

            val categoryCell = dataRow.createCell(1)
            categoryCell.setCellValue(if (operation.type) operation.category_expense else operation.category_income)

            val subcategoryCell = dataRow.createCell(2)
            subcategoryCell.setCellValue(operation.subcategory)

            val amountCell = dataRow.createCell(3)
            amountCell.setCellValue(operation.amount)

        }

        val file = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            File(requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "file$formattedDate.xls")
        } else {
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "file$formattedDate.xls")
        }

        try {
            val fileOutputStream = FileOutputStream(file)
            workbook.write(fileOutputStream)
            fileOutputStream.close()
            Toast.makeText(requireContext(), "Excel file created at: ${file.absolutePath}", Toast.LENGTH_SHORT).show()
            Log.d("ExcelFragment", "Excel file created successfully at: ${file.absolutePath}")
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Error creating Excel file", Toast.LENGTH_SHORT).show()
            Log.d("ExcelFragment", "Error creating Excel file: ${e.message}")
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == WRITE_EXTERNAL_STORAGE_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("ExcelFragment", "Permission granted, fetching operations")
                if (userId != null) {
                    fetchOperations(userId)
                }
            } else {
                Toast.makeText(
                    requireContext(),
                    "Permission to write to external storage denied",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(ExcelViewModel::class.java)
    }

}

class ExcelViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}

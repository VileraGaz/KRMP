package com.example.kursproject.tables

data class Budget (
    val sum: Double,
    val category: String,
    val startDate: Long, // Дата начала периода (можно использовать тип Long для хранения timestamp)
    val endDate: Long, // Дата окончания периода
)
package com.example.kursproject

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kursproject.databinding.ActivityCategoryBinding
import com.example.kursproject.databinding.ActivityMainBinding
import com.example.kursproject.databinding.FragmentAddOperationBinding
import com.example.kursproject.databinding.ItemCategoryBinding
import com.example.kursproject.tables.Category
import com.example.kursproject.tables.User
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class CategoryActivity : AppCompatActivity() {

    private lateinit var adapter: CategoryAdapter
    lateinit var auth: FirebaseAuth
    lateinit var binding: ActivityCategoryBinding
    private var currentCategories: MutableList<Category>? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        binding.recyclerViewCategories.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewCategories.setHasFixedSize(true)

        funOfShow("expenseCategories") // по умолчанию при открытии страницы
        addCategory("expenseCategories")

        binding.consumption2.setOnClickListener {
            binding.consumption2.setBackgroundColor(Color.parseColor("#2080EE"))
            binding.income2.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.consumption2.setTextColor(Color.parseColor("#FFFFFF"))
            binding.income2.setTextColor(Color.parseColor("#2080EE"))
            funOfShow("expenseCategories")
            addCategory("expenseCategories")
        }

        binding.income2.setOnClickListener {
            binding.income2.setBackgroundColor(Color.parseColor("#2080EE"))
            binding.consumption2.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.consumption2.setTextColor(Color.parseColor("#2080EE"))
            binding.income2.setTextColor(Color.parseColor("#FFFFFF"))
            funOfShow("incomeCategories")
            addCategory("incomeCategories")
        }

        binding.OKbtn.setOnClickListener{
            finish()
        }

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter(newText ?: "")
                return true
            }
        })


    }


    private fun funOfShow(type : String){
        val currentUser = getCurrentUser()

        currentUser?.id?.let { userId ->
            val databaseReference = FirebaseDatabase.getInstance().getReference().child("Users")
                .child(userId).child("userCategories").child(type)
            showCategories(databaseReference, type)
        }
    }

    private fun showCategories(categoriesReference: DatabaseReference, type: String) {
        categoriesReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val categoriesList = mutableListOf<Category>()
                for (categorySnapshot in dataSnapshot.children) {
                    val categoryName = categorySnapshot.child("name").getValue(String::class.java)
                    val categoryImage = categorySnapshot.child("iconResourceId").getValue(Int::class.java) ?: R.drawable.food
                    val subcategoriesSnapshot = categorySnapshot.child("subcategories")
                    val subcategoriesList = mutableListOf<String>()
                    for (subSnapshot in subcategoriesSnapshot.children) {
                        val subcategory = subSnapshot.getValue(String::class.java)
                        subcategory?.let {
                            subcategoriesList.add(it)
                        }
                    }
                    categoryName?.let {
                        val category = Category(name = it, iconResourceId = categoryImage, subcategories = subcategoriesList)
                        categoriesList.add(category)
                    }
                }
                adapter = CategoryAdapter(categoriesList) { category ->
                    // При клике на категорию открываем ChangeCategoryActivity
                    val intent = Intent(this@CategoryActivity, ChangeCategoryActivity::class.java)
                    intent.putExtra("categoryName", category.name)
                    intent.putExtra("categoryImageId", category.iconResourceId)
                    intent.putExtra("subcategories", ArrayList(category.subcategories))
                    intent.putExtra("type", type)
                    startActivity(intent)
                }
                adapter.setOnDeleteClickListener { category ->
                    showDeleteDialog(category, type)
                }
                binding.recyclerViewCategories.adapter = adapter
            }

            override fun onCancelled(databaseError: DatabaseError) {
                showToast("Ошибка при загрузке категорий: ${databaseError.message}")
            }
        })
    }

    private fun addCategory(type : String){
        binding.fabAddCategory.setOnClickListener{
            val i = Intent(this@CategoryActivity, AddCategoryActivity::class.java)
            i.putExtra("type", type)
            startActivity(i)
        }

    }

    private fun showDeleteDialog(category: Category, type : String) { // работает правильно
        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle("Удаление")
        alertDialogBuilder.setMessage("Вы действительно хотите удалить категорию '${category.name}'?")
        alertDialogBuilder.setPositiveButton("Да") { _, _ ->
            val reference = FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().currentUser!!.uid)
                .child("userCategories").child(type)

            reference.orderByChild("name").equalTo(category.name).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    for (snapshot in dataSnapshot.children) {
                        snapshot.ref.removeValue() // Удаление узла
                        showToast("Категория '${category.name}' успешно удалена")
                        currentCategories?.remove(category)
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    showToast("Ошибка при удалении категории '${category.name}': ${databaseError.message}")
                }
            })
        }
        alertDialogBuilder.setNegativeButton("Нет") { dialog, _ ->
            dialog.dismiss()
        }
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }


    private fun getCurrentUser(): User? {
        val firebaseUser = auth.currentUser // Получаем текущего пользователя Firebase
        return if (firebaseUser != null) {
            // Пользователь аутентифицирован, возвращаем объект User с категориями по умолчанию
            User(id = firebaseUser.uid,
                username = "",
                email = "",
                userOperations = mutableListOf()) // Передаем пустые значения для username и email
        } else {
            // Пользователь не аутентифицирован, возвращаем null или выполняем необходимые действия
            null
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }


    private inner class CategoryAdapter(
        private val categories: List<Category>,
        private val onItemClick: (Category) -> Unit
    ) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

        private var onDeleteClickListener: ((Category) -> Unit)? = null
        private var filteredCategories: List<Category> = categories

        fun setOnDeleteClickListener(listener: (Category) -> Unit) {
            onDeleteClickListener = listener
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
            val binding = ItemCategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return CategoryViewHolder(binding)
        }

        override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
            val category = filteredCategories[position]
            holder.bind(category)
        }

        override fun getItemCount(): Int = filteredCategories.size

        inner class CategoryViewHolder(private val binding: ItemCategoryBinding) : RecyclerView.ViewHolder(binding.root) {
            fun bind(category: Category) {
                binding.categoryName.text = category.name
                binding.imageCategory.setImageResource(category.iconResourceId)
                binding.availableSubcategory.text = if (category.subcategories.isNotEmpty()) "Есть подкатегории" else "Нет подкатегорий"
                binding.root.setOnClickListener { onItemClick(category) }
                binding.categoryDelete.setOnClickListener { onDeleteClickListener?.invoke(category) }
            }
        }

        fun filter(query: String) {
            filteredCategories = if (query.isEmpty()) {
                categories
            } else {
                categories.filter { it.name.contains(query, ignoreCase = true) }
            }
            notifyDataSetChanged()
        }
    }

}


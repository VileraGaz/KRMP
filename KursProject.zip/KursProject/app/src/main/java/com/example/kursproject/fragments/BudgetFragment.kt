package com.example.kursproject.fragments

import android.content.Intent
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.lifecycle.ViewModel
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kursproject.Choise
import com.example.kursproject.R
import com.example.kursproject.tables.Budget
import com.example.kursproject.tables.Operation
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BudgetFragment : Fragment() {

    companion object {
        fun newInstance() = BudgetFragment()
    }

    private lateinit var viewModel: BudgetViewModel
    private lateinit var recyclerView: RecyclerView
    private lateinit var budgetAdapter: BudgetFragment.BudgetAdapter
    private lateinit var budgetList: MutableList<Budget>
    private var totalAmount: Double = 0.0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        val view = inflater.inflate(R.layout.fragment_budget, container, false)
        recyclerView = view.findViewById(R.id.recyclerView2)
        recyclerView.layoutManager = LinearLayoutManager(context)
        budgetList = mutableListOf()
        budgetAdapter = BudgetAdapter(budgetList)
        recyclerView.adapter = budgetAdapter

        val imageView = view.findViewById<ImageView>(R.id.imageView4)
        imageView.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_budgetFragment_to_addBudgetFragment)
        }

        val btn = view.findViewById<Button>(R.id.addOp)
        btn.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_budgetFragment_to_addBudgetFragment)
        }

        val userId = FirebaseAuth.getInstance().currentUser?.uid
        val databaseReference = FirebaseDatabase.getInstance().getReference("Users/$userId/Budget")
        budgetList.sortByDescending { it.startDate }




        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                for (operationSnapshot in dataSnapshot.children) {
                    val sum = operationSnapshot.child("sum").getValue(Double::class.java) ?: 0.0
                    val category = operationSnapshot.child("category").getValue(String::class.java) ?: ""
                    val startDate = operationSnapshot.child("startDate").getValue(Long::class.java) ?: 0L
                    val endDate = operationSnapshot.child("endDate").getValue(Long::class.java) ?: 0L

                    val budget = Budget(sum, category, startDate, endDate)
                    budgetList.add(budget)
                }

                budgetAdapter.notifyDataSetChanged()

                if (budgetList.isEmpty()) {
                    // Отображаем элементы, если список операций пуст
                    view.findViewById<TextView>(R.id.textView10).visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.textView11).visibility = View.VISIBLE
                    view.findViewById<ImageView>(R.id.imageViewN).visibility = View.VISIBLE
                    view.findViewById<Button>(R.id.addOp).visibility = View.VISIBLE
                } else {
                    // Скрываем элементы, если список операций не пуст
                    view.findViewById<TextView>(R.id.textView10).visibility = View.GONE
                    view.findViewById<TextView>(R.id.textView11).visibility = View.GONE
                    view.findViewById<ImageView>(R.id.imageViewN).visibility = View.GONE
                    view.findViewById<Button>(R.id.addOp).visibility = View.GONE
                }

            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle errors
            }
        })

        return view
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(BudgetViewModel::class.java)
        // TODO: Use the ViewModel
    }

    private inner class BudgetAdapter(private val budget: List<Budget>) : RecyclerView.Adapter<BudgetFragment.BudgetViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BudgetFragment.BudgetViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.budget_list_item, parent, false)
            return BudgetViewHolder(view)
        }

        override fun onBindViewHolder(holder: BudgetFragment.BudgetViewHolder, position: Int) {
            val budget = budget[position]
            holder.bind(budget, position)
        }

        override fun getItemCount(): Int {
            return budget.size
        }
    }

    private fun Double.formatAmountWithCurrency(currencySymbol: String): String {
        val formattedAmount = if (this == this.toLong().toDouble()) {
            String.format("%.0f", this)
        } else {
            String.format("%.2f", this)
        }
        return "$formattedAmount $currencySymbol"
    }

    private inner class BudgetViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val dateTextView: TextView = itemView.findViewById(R.id.dateBudget)
        private val amountTextView: TextView = itemView.findViewById(R.id.sumTextView)
        private val categoryTextView: TextView = itemView.findViewById(R.id.categoryTextView)
        private val spentTexView: TextView = itemView.findViewById(R.id.spent)
        private val ostTextView: TextView = itemView.findViewById(R.id.ostatok)
        private val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)

        fun bind(budget: Budget, position: Int) {
            var start = SimpleDateFormat("dd MMMM yyyy", Locale("ru")).format(budget.startDate)
            var end = SimpleDateFormat("dd MMMM yyyy", Locale("ru")).format(budget.endDate)

            dateTextView.text = "$start - $end"
            amountTextView.text = budget.sum.formatAmountWithCurrency("₽")
            categoryTextView.text = budget.category
            val userId = FirebaseAuth.getInstance().currentUser?.uid
            var categoryTotalAmount = 0.0
            val operationReference = FirebaseDatabase.getInstance().getReference("Users/$userId/Operations")
            operationReference.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    for (operationSnapshot in dataSnapshot.children) {
                        val amount = operationSnapshot.child("amount").getValue(Double::class.java) ?: 0.0
                        val category = operationSnapshot.child("category_expense").getValue(String::class.java) ?: ""
                        val date = operationSnapshot.child("date").getValue(Long::class.java) ?: 0L

                        if (category == budget.category && date >= budget.startDate && date <= budget.endDate) {
                            categoryTotalAmount += amount
                        }

                        if (budget.category == "Все категории" &&
                            date >= budget.startDate &&
                            date <= budget.endDate) {
                            categoryTotalAmount += amount
                        }
                    }

                    // Расчет процента прогресса
                    val totalBudget = budget.sum
                    val progressMade = categoryTotalAmount
                    val progressPercentage = (progressMade / totalBudget) * 100

                    // Обновление ProgressBar
                    progressBar.max = totalBudget.toInt()
                    progressBar.progress = progressMade.toInt()

                    spentTexView.text = categoryTotalAmount.formatAmountWithCurrency("₽")
                    ostTextView.text = (budget.sum - categoryTotalAmount).formatAmountWithCurrency("₽")
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Handle errors
                }
            })
        }
    }


}

class BudgetViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
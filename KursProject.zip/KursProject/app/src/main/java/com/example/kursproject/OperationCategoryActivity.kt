package com.example.kursproject

import android.app.Activity
import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextThemeWrapper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kursproject.databinding.ActivityCategoryBinding
import com.example.kursproject.databinding.ItemOperationCategoryBinding
import com.example.kursproject.tables.Category
import com.example.kursproject.tables.User
import com.google.android.material.button.MaterialButton
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class OperationCategoryActivity : AppCompatActivity() {

    lateinit var binding: ActivityCategoryBinding
    private lateinit var operationCategoryAdapter: OperationCategoryAdapter
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth

        binding.apply {
            buttonsContainer.visibility = View.GONE
            fabAddCategory.visibility = View.GONE
            recyclerViewCategories.layoutParams.height = 1800
        }

        binding.OKbtn.setOnClickListener{
            finish()
        }

        binding.recyclerViewCategories.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewCategories.setHasFixedSize(true)

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                operationCategoryAdapter.filter(newText ?: "")
                return true
            }
        })

        val type = intent.getStringExtra("type") ?: ""
        funOfShow(type)


    }


    private fun funOfShow(type: String) {
        val currentUser = getCurrentUser()

        currentUser?.id?.let { userId ->
            val databaseReference = FirebaseDatabase.getInstance().getReference().child("Users")
                .child(userId).child("userCategories").child(type)
            showCategories(databaseReference, type)
        }
    }

    private fun showCategories(categoriesReference: DatabaseReference, type: String) {
        categoriesReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val categoriesList = mutableListOf<Category>()
                for (categorySnapshot in dataSnapshot.children) {
                    val categoryName = categorySnapshot.child("name").getValue(String::class.java)
                    val categoryImage = categorySnapshot.child("iconResourceId").getValue(Int::class.java) ?: R.drawable.food
                    val subcategoriesSnapshot = categorySnapshot.child("subcategories")
                    val subcategoriesList = mutableListOf<String>()
                    for (subSnapshot in subcategoriesSnapshot.children) {
                        val subcategory = subSnapshot.getValue(String::class.java)
                        subcategory?.let {
                            subcategoriesList.add(it)
                        }
                    }
                    categoryName?.let {
                        val category = Category(name = it, iconResourceId = categoryImage, subcategories = subcategoriesList)
                        categoriesList.add(category)
                    }
                }
                operationCategoryAdapter = OperationCategoryAdapter(categoriesList)
                binding.recyclerViewCategories.adapter = operationCategoryAdapter
            }

            override fun onCancelled(databaseError: DatabaseError) {
                showToast("Ошибка при загрузке категорий: ${databaseError.message}")
            }
        })
    }


    private fun getCurrentUser(): User? {
        val firebaseUser = auth.currentUser // Получаем текущего пользователя Firebase
        return if (firebaseUser != null) {
            // Пользователь аутентифицирован, возвращаем объект User с категориями по умолчанию
            User(
                id = firebaseUser.uid,
                username = "",
                email = "",
                userOperations = mutableListOf()
            ) // Передаем пустые значения для username и email
        } else {
            // Пользователь не аутентифицирован, возвращаем null или выполняем необходимые действия
            null
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }


    private inner class OperationCategoryAdapter(
        private val categories: List<Category>,
    ) : RecyclerView.Adapter<OperationCategoryAdapter.OperationCategoryViewHolder>() {

        private var filteredCategories: List<Category> = categories
        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): OperationCategoryViewHolder {
            val binding = ItemOperationCategoryBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            return OperationCategoryViewHolder(binding)
        }

        override fun onBindViewHolder(holder: OperationCategoryViewHolder, position: Int) {
            val category = filteredCategories[position]
            holder.bind(category)
        }

        override fun getItemCount(): Int = filteredCategories.size

        inner class OperationCategoryViewHolder(private val binding: ItemOperationCategoryBinding) :
            RecyclerView.ViewHolder(binding.root) {
            fun bind(category: Category) {
                binding.categoryName.text = category.name
                binding.imageCategory.setImageResource(category.iconResourceId)
                binding.root.setOnClickListener {
                    val resultIntent = Intent()
                    resultIntent.putExtra("thisCategoryName", category.name)
                    resultIntent.putExtra("thisImageId", category.iconResourceId)
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                }

                val subcategoryAdapter =
                    OperationSubcategoryAdapter(category.name, category.subcategories, category.iconResourceId)
                binding.availableSubcategories.apply {
                    layoutManager = LinearLayoutManager(
                        binding.root.context,
                        LinearLayoutManager.HORIZONTAL, // ажжваж
                        false
                    )
                    adapter = subcategoryAdapter
                }

            }
        }

        fun filter(query: String) {
            filteredCategories = if (query.isEmpty()) {
                categories
            } else {
                categories.filter { category ->
                    category.name.contains(query, ignoreCase = true) ||
                            category.subcategories.any { it.contains(query, ignoreCase = true) }
                }
            }
            notifyDataSetChanged()
        }
    }

    private inner class OperationSubcategoryAdapter(
        private val categoryName: String,
        private val subcategories: List<String>,
        private val iconResourceId: Int
    ) : RecyclerView.Adapter<OperationSubcategoryAdapter.OperationSubcategoryViewHolder>() {

        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): OperationSubcategoryViewHolder {
            val context = parent.context
            val button = MaterialButton(ContextThemeWrapper(context, R.style.btn_small), null, 0).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                setTextSize(12f)
                setPadding(16, 15, 16, 11)
                stateListAnimator = null // Убираем тень
                setAllCaps(false)
                setCornerRadius(15.dpToPx())
            }
            val marginLayoutParams = ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            marginLayoutParams.setMargins(0, 0, 30, 0) // Установка правого отступа между кнопками
            button.layoutParams = marginLayoutParams

            return OperationSubcategoryViewHolder(button)
        }

        override fun onBindViewHolder(holder: OperationSubcategoryViewHolder, position: Int) {
            holder.bind(subcategories[position])
        }
        fun Int.dpToPx(): Int {
            return (this * Resources.getSystem().displayMetrics.density).toInt()
        }

        override fun getItemCount(): Int = subcategories.size

        inner class OperationSubcategoryViewHolder(private val button: MaterialButton) :
            RecyclerView.ViewHolder(button) {
            fun bind(subcategory: String) {
                button.text = subcategory
                button.setOnClickListener {
                    val resultIntent = Intent()
                    resultIntent.putExtra("thisCategoryName", categoryName)
                    resultIntent.putExtra("thisSubcategoryName", subcategory)
                    resultIntent.putExtra("thisImageId", iconResourceId)
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                }
            }
        }
    }
}

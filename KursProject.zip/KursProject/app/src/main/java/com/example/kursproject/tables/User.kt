package com.example.kursproject.tables

data class User(
    val id: String,
    val username: String,
    val email: String,
    val userCategories: UserCategories = UserCategories(), // Объект для хранения категорий пользователя
    val userOperations: MutableList<Operation> = mutableListOf(), // Список операций пользователя
    val userBudget: MutableList<Budget> = mutableListOf() // список бюджетов
) {
    fun addOperation(operation: Operation) {
        this.userOperations.add(operation)
    }

    fun addBudget(budget: Budget) {
        this.userBudget.add(budget)
    }
}
package com.example.kursproject.fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.navigation.fragment.findNavController
import com.example.kursproject.R
import com.example.kursproject.databinding.FragmentChangePasswordBinding
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth

class ChangePassword : Fragment() {

    companion object {
        fun newInstance() = ChangePassword()
    }

    private lateinit var viewModel: ChangePasswordViewModel
    lateinit var binding: FragmentChangePasswordBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentChangePasswordBinding.inflate(inflater, container, false)
        val navController = findNavController()
        binding.OKbtn.setOnClickListener {
            navController.navigate(R.id.action_changePassword_to_settingsFragment)
        }

        binding.oldPassword.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        binding.newPassword.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        binding.newPasswordRepeat.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        binding.buttonChange.setOnClickListener {
            val user = FirebaseAuth.getInstance().currentUser
            val oldPasswordInput = binding.oldPassword.text.toString()
            val newPasswordInput = binding.newPassword.text.toString()
            val newPasswordRepeatInput = binding.newPasswordRepeat.text.toString()

            if (TextUtils.isEmpty(oldPasswordInput) || TextUtils.isEmpty(newPasswordInput) || TextUtils.isEmpty(newPasswordRepeatInput)) {
                // Проверка на пустой ввод
                Toast.makeText(requireContext(), "Заполните все поля", Toast.LENGTH_SHORT).show()
            } else {
                // Проверка старого пароля и совпадения нового пароля и его повтора
                val credential = EmailAuthProvider.getCredential(user!!.email!!, oldPasswordInput)
                user.reauthenticate(credential)
                    .addOnCompleteListener { reauthTask ->
                        if (reauthTask.isSuccessful) {
                            if (newPasswordInput == newPasswordRepeatInput) {
                                // Правильный старый пароль и совпадение нового пароля и его повтора
                                user.updatePassword(newPasswordInput)
                                    .addOnCompleteListener { updateTask ->
                                        if (updateTask.isSuccessful) {
                                            // Пароль успешно обновлен
                                            Toast.makeText(requireContext(), "Пароль успешно обновлен", Toast.LENGTH_SHORT).show()
                                            Log.d("ChangePasswordFragment", "Пароль обновлен")
                                        } else {
                                            // Обработка неудачи обновления пароля
                                            Toast.makeText(requireContext(), "Не удалось обновить пароль", Toast.LENGTH_SHORT).show()
                                            Log.e("ChangePasswordFragment", "Не удалось обновить пароль")
                                        }
                                    }
                            } else {
                                // Новый пароль и его повтор не совпадают
                                Toast.makeText(requireContext(), "Новый пароль и его повтор не совпадают", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            // Неправильный старый пароль
                            Toast.makeText(requireContext(), "Неправильный старый пароль", Toast.LENGTH_SHORT).show()
                        }
                    }
            }
        }
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(ChangePasswordViewModel::class.java)
        // TODO: Use the ViewModel
    }

}

class ChangePasswordViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}